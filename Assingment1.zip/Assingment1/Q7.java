package Assingment1;

public class Q7 {

	public static void main(String[] args) 
	{
		
				System.out.println(8*1);
				System.out.println(8*2);
				System.out.println(8*3);
				System.out.println(8*10);
				
			}

		}


	
