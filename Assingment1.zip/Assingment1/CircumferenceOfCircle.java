package Assingment1;
import java.util.Scanner;  
import java.lang.Math; 
public class CircumferenceOfCircle  

	{  
	private static Scanner sc;

	public static void main(String[] args)   
	{  
	double circumference, radius;   
	sc = new Scanner (System.in);  
	System.out.print("Enter the radius of the circle: ");  
	radius=sc.nextDouble();  
	 
	circumference= Math.PI*2*radius;  
	
	System.out.println("The circumference of the circle is: "+circumference);  
	 double area = Math.PI*(radius*radius);  
	//prints the calculated area  
	System.out.println("The area of the circle is: "+area);  
	
	
	}    
	
	}    


